# Bulk WhatsApp Messaging for Frappe WhatsApp
# bulk_whatsapp_messaging.py

import frappe
from frappe import _
import json
from frappe.utils import cint, get_datetime, now
from frappe.model.document import Document
from frappe.model.naming import make_autoname

# Add these files to your frappe_whatsapp app

# 1. First, create a new DocType for Bulk WhatsApp Messaging
# Save this as a Python file in your app's folder: 
# frappe_whatsapp/frappe_whatsapp/doctype/bulk_whatsapp_message/bulk_whatsapp_message.py

class BulkWhatsAppMessage(Document):
    def autoname(self):
        self.name = make_autoname("BULK-WA-.YYYY.-.#####")
    
    def validate(self):
        # self.validate_message()
        self.validate_recipients()
    
    def validate_message(self):
        if not self.message_content:
            frappe.throw(_("Message content is required"))
    
    def validate_recipients(self):
        if not self.recipients and not self.recipient_list:
            frappe.throw(_("At least one recipient or a recipient list is required"))
        
        # If recipient list is provided, count recipients
        if self.recipient_type == 'Recipient List' and self.recipient_list:
            recipient_count = frappe.db.count("WhatsApp Recipient", {"parent": self.recipient_list})
            if recipient_count == 0:
                frappe.throw(_("Selected recipient list has no recipients"))
            self.recipient_count = recipient_count
        # If individual recipients are provided
        elif self.recipients:
            self.recipient_count = len(self.recipients)
    
    def on_submit(self):
        self.db_set("status", "Queued")
        self.queue_messages()
    
    def queue_messages(self):
        """Queue messages for sending"""
        if self.recipient_type == 'Recipient List' and self.recipient_list:
            # Fetch recipients from the recipient list
            recipients = frappe.get_all(
                "WhatsApp Recipient", 
                filters={"parent": self.recipient_list},
                fields=["mobile_number", "name", "recipient_name", "recipient_data"]
            )
            
            for recipient in recipients:
                frappe.enqueue_doc(
                    self.doctype, self.name,
                    "create_single_message",
                    "long", 4000,
                    recipient=recipient
                )
        else:
            # Use recipients from the current document
            for recipient in self.recipients:
                frappe.enqueue_doc(
                    self.doctype, self.name,
                    "create_single_message",
                    "long", 4000,
                    recipient=recipient
                )
    
    def create_single_message(self, recipient):
        """Create a single message in the queue"""
        # message_content = self.message_content
        
        # Replace variables in the message if any
        self.status == "In Progress"
        if recipient.get("recipient_data"):
            try:
                variables = json.loads(recipient.get("recipient_data", "{}"))
                # for var_name, var_value in variables.items():
                #     message_content = message_content.replace(f"{{{{{var_name}}}}}", str(var_value))
            except Exception as e:
                frappe.log_error(f"Error parsing recipient data: {str(e)}", "WhatsApp Bulk Messaging")
        
        # Create WhatsApp message
        wa_message = frappe.new_doc("WhatsApp Message")
        # wa_message.from_number = self.from_number
        wa_message.to = recipient.get("mobile_number")
        wa_message.message_type = "Text"
        # wa_message.message = message_content
        wa_message.flags.custom_ref_doc = json.loads(recipient.get("recipient_data", "{}"))
        wa_message.bulk_message_reference = self.name
        if self.whatsapp_account:
            wa_message.whatsapp_account = self.whatsapp_account
        
        # If template is being used
        if self.use_template:
            wa_message.template = self.template
            wa_message.message_type = 'Template'
            wa_message.use_template = self.use_template
            # Handle template variables if needed

            # handle MPM action JSON if product IDs and catalog ID are provided
            mpm_action = self.get_mpm_action_json()
            if mpm_action:
                # We store the action JSON so the outgoing API call can find it
                wa_message.product_catalog_json = json.dumps(mpm_action)

            if recipient.get("recipient_data") and self.variable_type=='Unique':
                wa_message.body_param = recipient.get("recipient_data")
            elif self.template_variables and self.variable_type=='Common':
                wa_message.body_param = self.template_variables
            if self.attach:
                wa_message.attach = self.attach
        
        # Set status to queued
        wa_message.status = "Queued"
        try:
            wa_message.insert(ignore_permissions=True)
        except Exception:
            self.db_set("status", "Partially Failed")
        # Update message count
        self.db_set("sent_count", cint(self.sent_count) + 1)
        if self.recipient_count == self.sent_count:
            self.db_set("status", "Completed")

    def retry_failed(self):
        """Retry failed messages by re-sending to Meta.

        The original send lives in WhatsAppMessage.before_insert, which only
        fires on first creation. For an existing Failed row we call
        send_outgoing() explicitly — queued on the "long" worker the same
        way queue_messages does, so large batches don't block the request.
        """
        failed_messages = frappe.get_all(
            "WhatsApp Message",
            filters={
                "bulk_message_reference": self.name,
                "status": "Failed"
            },
            fields=["name"]
        )

        for msg in failed_messages:
            frappe.enqueue_doc(
                self.doctype, self.name,
                "resend_single_message",
                "long", 4000,
                message_name=msg.name,
            )

        frappe.msgprint(_("{0} message(s) requeued for sending").format(len(failed_messages)))

    def resend_single_message(self, message_name):
        """Worker entry: re-send a single failed WhatsApp Message."""
        message_doc = frappe.get_doc("WhatsApp Message", message_name)
        # Clear the prior message_id so the template send path (which gates
        # on `not self.message_id`) runs again.
        message_doc.message_id = None
        message_doc.status = "Queued"
        message_doc.db_update()
        try:
            message_doc.send_outgoing()
            message_doc.status = "Success"
            message_doc.db_update()
        except Exception:
            message_doc.status = "Failed"
            message_doc.db_update()
            frappe.log_error(
                title=f"WhatsApp bulk retry failed: {message_doc.name}"
            )
        
    def get_progress(self):
        """Get sending progress for this bulk message"""
        total = self.recipient_count
        sent = frappe.db.count("WhatsApp Message", {
            "bulk_message_reference": self.name,
            "status": ["in", ["sent","delivered", "Success", "read"]]
        })
        failed = frappe.db.count("WhatsApp Message", {
            "bulk_message_reference": self.name,
            "status": "Failed"
        })
        queued = frappe.db.count("WhatsApp Message", {
            "bulk_message_reference": self.name,
            "status": "Queued"
        })
        
        return {
            "total": total,
            "sent": sent,
            "failed": failed,
            "queued": queued,
            "percent": (sent / total * 100) if total else 0
        }

    def get_mpm_action_json(self):
        """Constructs the Meta 'action' JSON by fetching Catalog ID from the Account"""
        if not self.whatsapp_account or not self.thumbnail_product_retailer_id or not self.product_ids:
            return None

        raw_ids = self.product_ids
        # Clean the product list from the user input
        # Convert to a set to remove duplicates, then back to a list
        product_list = list(dict.fromkeys([p.strip() for p in raw_ids.split(",") if p.strip()]))

        if len(product_list) > 30:
            product_list = product_list[:30]
            frappe.msgprint(_("Note: Only the first 30 products were included due to WhatsApp limitations."),
                            indicator="orange")
        return {
            "thumbnail_product_retailer_id": self.thumbnail_product_retailer_id,
            "sections": [
                {
                    "title": self.mpm_header or "Our Products",
                    "product_items": [
                        {"product_retailer_id": pid} for pid in product_list
                    ]
                }
            ]
        }
